#ifndef SC_LEVEL_PLATE_M
#define SC_LEVEL_PLATE_M
PROGMEM const char LEVEL_PLATE_M[] = { -1 };
#define LEVEL_PLATE_M_LENGTH -1
#endif
