#ifndef SC_CHANGE_LEFT
#define SC_CHANGE_LEFT
PROGMEM const char CHANGE_LEFT[] = { -1 };
#define CHANGE_LEFT_LENGTH -1
#endif
