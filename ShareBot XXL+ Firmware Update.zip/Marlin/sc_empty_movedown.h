#ifndef SC_MOVEDOWN
#define SC_MOVEDOWN
PROGMEM const char MOVEDOWN[] = { -1 };
#define MOVEDOWN_LENGTH -1
#endif
