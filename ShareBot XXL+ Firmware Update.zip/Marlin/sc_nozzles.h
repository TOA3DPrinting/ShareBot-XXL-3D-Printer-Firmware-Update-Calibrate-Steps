#ifndef SC_NOZZLES
#define SC_NOZZLES
PROGMEM const char NOZZLES[] = {84,48,10,0 };
#define NOZZLES_LENGTH 3
#endif
