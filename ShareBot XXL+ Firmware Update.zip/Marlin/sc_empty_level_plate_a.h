#ifndef SC_LEVEL_PLATE_A
#define SC_LEVEL_PLATE_A
PROGMEM const char LEVEL_PLATE_A[] = { -1 };
#define LEVEL_PLATE_A_LENGTH -1
#endif
